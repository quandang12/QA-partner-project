# QA_Github_Partner_Exercise
IHCC QA Partner Exercise

Mark's Comments
